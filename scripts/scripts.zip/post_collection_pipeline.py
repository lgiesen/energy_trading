#!/usr/bin/env python3
"""Post-collection pipeline wrapper: merge -> clean -> transform -> features.

Usage:
    ./.venv/bin/python scripts/post_collection_pipeline.py \
        --clip-start 2020-11-30T23:00:00Z \
        --clip-end 2025-12-31T23:00:00Z
"""
from __future__ import annotations

import argparse
import logging
import subprocess
import sys
from pathlib import Path

LOGGER = logging.getLogger(__name__)


def _run(cmd: list[str]) -> None:
    LOGGER.info("-> %s", " ".join(cmd))
    subprocess.run(cmd, check=True)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    parser = argparse.ArgumentParser(
        description="Run post-collection processing (merge -> clean -> transform -> features)."
    )
    parser.add_argument("--data-dir", default="data/raw", help="Directory containing raw parquet files.")
    parser.add_argument(
        "--merged",
        default="data/processed/all_data.parquet",
        help="Merged parquet output.",
    )
    parser.add_argument(
        "--clean-out",
        default="data/processed/cleaned_data.parquet",
        help="Cleaned parquet output.",
    )
    parser.add_argument(
        "--refined-out",
        default="data/processed/all_data_refined.parquet",
        help="Refined parquet output (after dropping redundant features).",
    )
    parser.add_argument(
        "--transformed-out",
        default="data/processed/all_data_transformed.parquet",
        help="Transformed parquet output.",
    )
    parser.add_argument(
        "--features-out",
        default="data/features/all_data_features.parquet",
        help="Features parquet output.",
    )
    parser.add_argument(
        "--outages-hourly-out",
        default="data/processed/outages_hourly.parquet",
        help="Hourly outages parquet output (sidecar feature table).",
    )
    parser.add_argument(
        "--planned-outages-in",
        default="data/raw/entsoe_outages/planned_generation_outages.parquet",
        help="Planned outages parquet input.",
    )
    parser.add_argument(
        "--unplanned-outages-in",
        default="data/raw/entsoe_outages/unplanned_generation_outages.parquet",
        help="Unplanned outages parquet input.",
    )
    parser.add_argument(
        "--outages-days-ahead",
        type=int,
        default=7,
        help="Forecast horizon for outages hourly transform (default: 7 days).",
    )
    parser.add_argument(
        "--clip-start",
        default="2020-11-30T23:00:00Z",
        help="Clip start (timezone-aware recommended, UTC Z).",
    )
    parser.add_argument(
        "--clip-end",
        default="2025-12-31T23:00:00Z",
        help="Clip end (timezone-aware recommended, UTC Z).",
    )
    parser.add_argument(
        "--resample-freq",
        default="1h",
        help="Resample frequency passed to merge_data (default: 1h).",
    )
    parser.add_argument(
        "--skip-transform",
        action="store_true",
        help="Stop after cleaning step.",
    )
    parser.add_argument(
        "--skip-features",
        action="store_true",
        help="Stop after transform step.",
    )
    parser.add_argument(
        "--skip-outages-hourly",
        action="store_true",
        help="Skip sidecar transform of ENTSO-E outages to hourly table.",
    )
    args = parser.parse_args()

    py = sys.executable
    Path(args.merged).parent.mkdir(parents=True, exist_ok=True)
    Path(args.refined_out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.clean_out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.transformed_out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.features_out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.outages_hourly_out).parent.mkdir(parents=True, exist_ok=True)

    # 1) Merge collected raw files.
    merge_cmd = [
        py,
        "-m",
        "energy_trading.ingestion.merge_data",
        "--data-dir",
        args.data_dir,
        "--out",
        args.merged,
        "--clip-start",
        args.clip_start,
        "--clip-end",
        args.clip_end,
    ]
    if args.resample_freq is not None:
        merge_cmd.extend(["--resample-freq", args.resample_freq])
    _run(merge_cmd)

    # 2) Refine merged data (source consolidation + market-specific features).
    _run(
        [
            py,
            "-m",
            "energy_trading.processing.refine_market_data",
            "--in",
            args.merged,
            "--out",
            args.refined_out,
        ]
    )

    # 3) Handle missing values.
    _run(
        [
            py,
            "-m",
            "energy_trading.processing.handle_missing_values",
            "--in",
            args.refined_out,
            "--out",
            args.clean_out,
        ]
    )

    if args.skip_transform:
        LOGGER.info("Stopping after cleaning (--skip-transform).")
        return

    # 4) Transform.
    _run(
        [
            py,
            "-m",
            "energy_trading.processing.transform_data",
            "--in",
            args.clean_out,
            "--out",
            args.transformed_out,
        ]
    )

    if args.skip_features:
        LOGGER.info("Stopping after transform (--skip-features).")
        return

    # 5) Build features.
    _run(
        [
            py,
            "-m",
            "energy_trading.features.build_features",
            "--in",
            args.transformed_out,
            "--out",
            args.features_out,
        ]
    )

    # 6) Build sidecar hourly outage features (if raw outage files are available).
    if not args.skip_outages_hourly:
        planned_path = Path(args.planned_outages_in)
        unplanned_path = Path(args.unplanned_outages_in)
        if planned_path.exists() and unplanned_path.exists():
            outage_transform = Path(__file__).with_name("transform_entsoe_outages_hourly.py")
            _run(
                [
                    py,
                    str(outage_transform),
                    "--planned",
                    str(planned_path),
                    "--unplanned",
                    str(unplanned_path),
                    "--out",
                    args.outages_hourly_out,
                    "--days-ahead",
                    str(args.outages_days_ahead),
                ]
            )
        else:
            LOGGER.warning(
                "Skipping outages-hourly transform: missing input files (%s, %s).",
                planned_path,
                unplanned_path,
            )

    LOGGER.info("Post-collection pipeline completed.")


if __name__ == "__main__":
    main()
